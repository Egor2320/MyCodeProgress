var searchData=
[
  ['coef_0',['coef',['../struct_library_1_1_cell.html#a7462ef9886a41d1d30c03b6fcce4d064',1,'Library::Cell']]]
];
