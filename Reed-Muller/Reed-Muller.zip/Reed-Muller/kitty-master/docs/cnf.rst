CNF representations
===================

The header ``<kitty/cnf.hpp>`` implements methods to compute conjunctive normal
forms (CNF).

.. doc_brief_table::
   cnf_characteristic


