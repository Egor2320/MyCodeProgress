Enumeration
===========

The header ``<kitty/enumeration.hpp>`` implements methods to enumerate
Boolean function representatives based on canonization functions.

.. doc_brief_table::
   fuller_neighborhood_enumeration


