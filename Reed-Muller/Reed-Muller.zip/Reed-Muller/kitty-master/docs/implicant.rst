Implicants
==========

The header ``<kitty/implicant.hpp>`` implements methods to find implicants and prime implicants.

.. doc_brief_table::
   get_minterms
   get_jbuddies
   get_prime_implicants_morreale



