ISOP representations
====================

The header ``<kitty/isop.hpp>`` implements methods to compute irredundant sum-of-products (ISOP) representations.

.. doc_brief_table::
   isop


