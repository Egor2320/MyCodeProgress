#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include "reed_muller.h"
#include "helper.h"

using testing::Eq;
namespace {
	class ClassDeclaration : public testing::Test {
		public:
		Library::ReedMuller r;
		
		ClassDeclaration() {
			r;
		}
		
	};
}
TEST_F(ClassDeclaration, nameOfTheTest1){
	uint64_t size = 10;
	uint64_t bits = 1 << size;
	kitty::dynamic_truth_table t(size);
	std::string s = Library::Helper::generate(bits);
	kitty::create_from_binary_string(t,s);
	std::vector<Library::Cell> f = r.sythesize(t);
	for(int i = 0; i < bits; ++i){
		ASSERT_EQ(r.apply(f, Library::Helper::to2(i, size)), kitty::get_bit(t, i));
	}
	
}

