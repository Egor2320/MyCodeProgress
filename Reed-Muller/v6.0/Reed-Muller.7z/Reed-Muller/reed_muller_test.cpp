
#include "reed_muller_test.h"
#include "helper.h"
#include <algorithm>
#include <unordered_map>

namespace Library {
	ReedMullerTest::ReedMullerTest() = default;
	ReedMullerTest::~ReedMullerTest() = default;
	
	std::unordered_map<int, uint64_t> ReedMullerTest::synthesize(const kitty::dynamic_truth_table &t) {
		std::unordered_map<int, uint64_t> char_function = char_from_truth_table(t);
		std::unordered_map<int, uint64_t> result_function = char_from_function(char_function);
		return result_function;
	}
	
	//the last cell in func has the number of variables the func depends on as the "coef" field
	uint64_t ReedMullerTest::apply(std::unordered_map<int, uint64_t> &func, const std::string &s) {
		std::string s_ = s;
		std::reverse(s_.begin(), s_.end());
		std::vector<int> positions_of_ones;
		uint64_t num_var = func[-1];
		uint64_t res = 0;
		
		for(int i = 0; i < s_.size(); ++i){
			if(s_[i] == '1') positions_of_ones.push_back(i);
		}
		uint64_t sz = positions_of_ones.size();
		uint64_t base = 1 << sz;
		for(int i = 0; i < base; ++i){
			std::string str = Helper::to2(i, sz);
			int pos = 0;
			for(uint64_t j = 0; j < sz; ++j){
				if(str[j] == '1') pos += 1 << (positions_of_ones[sz - 1 - j]);
			}
			res ^= func[pos];
		}
		return res;
	}
	/*
	void ReedMullerTest::polynomical(std::vector<Cell> func) {
		if(func.size() == 2 && func[0].coef == 0){
			std::cout << "0";
			return;
		}
		for(int i = 0; i < func.size()-1; ++i){
			if(i == 0 && func[0].variables.empty()){
				std::cout << "1 ";
			}
			for(int variable : func[i].variables){
				std::cout << "x_" << variable + 1 << ' ';
			}
			
			if(i != func.size() - 2)std::cout << "^ ";
			
		}
	}*/
	
	std::unordered_map<int, uint64_t> ReedMullerTest::char_from_truth_table(const kitty::dynamic_truth_table &t) {
		std::unordered_map<int, uint64_t> char_function;
		uint64_t num_bits = t.num_bits();
		uint64_t num_var = t.num_vars();
		for(int i = 0; i < num_bits; ++i){
			char_function[i] = kitty::get_bit(t, i);
		}
		char_function[-1] = num_var;
		return char_function;
	}
	
	std::unordered_map<int, uint64_t> ReedMullerTest::char_from_function(std::unordered_map<int, uint64_t> &func) {
		std::unordered_map<int, uint64_t> result_function;
		uint64_t num_var = func[-1];
		uint64_t num_bits = 1 << num_var;
		for(int i = 0; i < num_bits; ++i){
			result_function[i] = apply(func, Helper::to2(i, num_var));
		}
		result_function[-1] = num_var;
		return result_function;
	}
	
}