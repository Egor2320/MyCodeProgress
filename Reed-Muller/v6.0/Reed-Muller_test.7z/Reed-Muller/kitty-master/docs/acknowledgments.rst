Acknowledgments
===============

The implementation of this truth table library is highly inspired by the truth
table functions in ABC_ by Alan Mishchenko.  Thanks to Luca Amaru, Winston
Haaswijk, D. Michael Miller, and Heinz Riener for helpful discussions and/or
sending bug fixes.

.. _ABC: https://bitbucket.org/alanmi/abc
