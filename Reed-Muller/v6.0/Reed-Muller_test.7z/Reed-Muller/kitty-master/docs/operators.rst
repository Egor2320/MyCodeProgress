Operators
=========

The header ``<kitty/operators.hpp>`` implements operator shortcuts to operations.

.. doc_brief_table::
   operator~
   operator&
   operator&=
   operator|
   operator|=
   operator^
   operator^=
   operator==
   operator!=
   operator<
   operator<<
   operator<<=
   operator>>
   operator>>=
