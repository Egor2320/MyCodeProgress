Printing
========

The header ``<kitty/print.hpp>`` implements functions to print truth tables.

.. doc_brief_table::
   print_binary
   print_hex
   print_kmap
   print_raw
   to_binary
   to_hex
   print_xmas_tree_for_function
   print_xmas_tree_for_functions
   anf_to_expression
